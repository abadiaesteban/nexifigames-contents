

ENT.Type = "anim"
ENT.Base = "base_anim"

ENT.PrintName		= "Loot"
ENT.Author			= ""
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

function ENT:SetupDataTables()


end
