--
-- ph_prop/shared.lua
-- Prop Hunt
--	
-- Created by Andrew Theis on 2013-03-09.
-- Copyright (c) 2010-2013 Andrew Theis. All rights reserved.
--
 

-- Entity information.
ENT.Type = "anim"
ENT.Base = "base_anim"