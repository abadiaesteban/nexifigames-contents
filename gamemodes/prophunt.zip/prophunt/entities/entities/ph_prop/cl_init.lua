--
-- ph_prop/cl_init.lua
-- Prop Hunt
--	
-- Created by Andrew Theis on 2013-03-09.
-- Copyright (c) 2010-2013 Andrew Theis. All rights reserved.
--


-- Include needed files.
include("shared.lua")


-- Draw the model.
function ENT:Draw()

	self.Entity:DrawModel()
	
end 